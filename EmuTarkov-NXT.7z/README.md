# EmuTarkov-NXT
Experimental, server and rewrite in C#
